import { Component } from '@angular/core';
import {NavController, AlertController} from 'ionic-angular';
import {AboutPage} from "../about/about";
import {MainPage} from "../Main/Main";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public username: String;
  public password: String;
  constructor(public navCtrl: NavController, public alertCtrl: AlertController) {

  }


  signIn() {
    var lclname = localStorage.getItem('username');
    var lclpwd = localStorage.getItem('password');

    if(this.username == lclname && this.password == lclpwd){
      this.navCtrl.push(MainPage).then();
    }else if(this.username == "" || this.password == "")
    {
      let alert = this.alertCtrl.create({
        title: 'Fields are empty',
        subTitle: 'Please enter Username and Password',
        buttons: ['OK']
      });
      alert.present().then();
    }
    else{
      let alert = this.alertCtrl.create({
        title: 'Unsuccessful Login',
        subTitle: 'Password or Username incorrect',
        buttons: ['OK']
      });
      alert.present().then();
    }
  }
  register(){
    this.navCtrl.push(AboutPage).then();
  }

}
