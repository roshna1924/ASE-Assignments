import { Component } from '@angular/core';
import {IonicPage,AlertController, NavController} from 'ionic-angular';
import {HomePage} from "../home/home";

@IonicPage()
@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {
  public username;
  public email;
  public password;
  public confirmpassword;


  constructor(public nav: NavController, public alertCtrl: AlertController) {

  }

  Signup() {
    if (this.password === this.confirmpassword) {
      localStorage.setItem('username', this.username);
      localStorage.setItem('emailId', this.email);
      localStorage.setItem('password', this.password);
      localStorage.setItem('confirm password', this.confirmpassword);
      let alert = this.alertCtrl.create({
        title: 'Registration successful!',
        subTitle: 'You are registered as ' + this.username,
        buttons: ['OK']
      });
      alert.present().then( );
      this.nav.push(HomePage).then();
    }else if(this.username == null || this.username == "" || this.email == null || this.email =="" || this.password == null || this.password == "" || this.confirmpassword == null || this.confirmpassword == "")
    {
      let alert = this.alertCtrl.create({
        title: 'All Fields are mandatory',
        subTitle: 'Please enter all fields',
        buttons: ['OK']
      });
      alert.present().then();
    }
      else {
      let alert = this.alertCtrl.create({
        title: 'Registration unsuccessful!',
        subTitle: 'Password and Confirm password does not match',
        buttons: ['OK']
      });
      alert.present().then();
    }
  }
}
