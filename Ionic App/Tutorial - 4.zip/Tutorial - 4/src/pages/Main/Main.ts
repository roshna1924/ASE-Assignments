import { Component ,ViewChild,ElementRef} from '@angular/core';
import {NavController, AlertController, IonicPage} from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import {HomePage} from '../home/home';
import {FindPage} from "../find/find";
import {CurrencyPage} from "../currency/currency";
import {SearchPage} from "../search/search";

@IonicPage()
@Component({
  selector: 'page-main',
  templateUrl: 'main.html'
})
export class MainPage {
  public rst:object;
  public gender:object;
  public accuracy:object;
  public name;
  constructor(public navC: NavController, public http: HttpClient,public alertC: AlertController) {
  }
  calender(){
  this.navC.push(FindPage).then();
  }
  currency() {
    this.navC.push(CurrencyPage).then();
  }
  searchDet(){
    this.navC.push(SearchPage).then();
  }

  logout(){
    let alert = this.alertC.create({
      title: 'Log out',
      buttons: ['OK']
    });
    alert.present().then();
    this.navC.push(HomePage).then();
  }

}

