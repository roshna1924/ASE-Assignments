import { Component, OnInit } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
public info: object ;
// public  useremail;
  constructor(private http: HttpClient) { }

  ngOnInit() {
  }

  myinfo() {
    // let token: string;
    const token = localStorage.getItem('authorization');
    console.log(JSON.stringify(token));
    const headers = new HttpHeaders().set('authorization', token);
    console.log(JSON.stringify(headers));
    this.http.get('http://localhost:3000/api/posts', {headers} ).subscribe( data => {
    this.info = data;
    console.log(data);
  });
    // const useremail = 'Roshnatoke@gmail.com';
}
}
