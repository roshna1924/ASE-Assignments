
const fs =  require('fs');
const yargs = require('yargs');

const notes = require('./notes.js');

// ------------ Begin - command configuration -----------------

const nameOptions = {
    describe: 'Name of a Customer',
    demand : true,
    alias : 'n'
};

const idOptions = {
    describe: 'Id of a Customer',
    demand : true,
    alias : 'i'
};
const emailOptions = {
    describe: 'Email id of a customer',
    demand : true,
    alias : 'e'
};
const addressOptions = {
    describe: 'Address of a customer',
    demand : true,
    alias : 'a'
}

const argv =  yargs

    .command('addcustomer','Add a new Customer',{
      customer_name: nameOptions,
      customer_id: idOptions,
      customer_email : emailOptions,
      customer_address : addressOptions
    })
    .command('updatecustomer','Update existing Customer',{
        customer_name: nameOptions,
        customer_id: idOptions,
        customer_email : emailOptions,
        customer_address : addressOptions
    })
    .command('listcustomer','List of all Customers')
    .command('readcustomer','Get particular customer data',{
        customer_name: nameOptions
    })
    .command('removecustomer','Remove a particular Customer',{
        customer_name: nameOptions
    })
    .help()
    .argv;


// ------------ End - command configuration -----------------


var command = yargs.argv._[0];


if (command === 'addcustomer'){
    var custadded = notes.addCust(argv.customer_name,argv.customer_id, argv.customer_email, argv.customer_address);
    if (custadded){
      notes.logNote(custadded);     //add a new note
    } else{
      console.log("Customer Name/Id has already exists");
    }
}

else if(command === 'updatecustomer'){
    var custupdated = notes.updateCust(argv.customer_name,argv.customer_id, argv.customer_email, argv.customer_address);
    if (custupdated){
       notes.logNote(custupdated);    //Print cust data
    } else{
        console.log("Customer Name does not exist");
    }
}

else if (command === 'listcustomer') {
  var AllCust = notes.getCustList();
  console.log(`Printing ${AllCust.length} customer(s).`);
    AllCust.forEach((note)=>{     //list all customer(s)
    notes.logNote(note);
  });
}

else if (command === 'readcustomer') {
   var custread = notes.getOneCust(argv.customer_name);
   if(custread){
    notes.logNote(custread);    //read a customer
          }
   else{
    console.log("Customer not found");
   }
}
else if (command === 'removecustomer') {
    var custRemoved = notes.remove(argv.customer_name);
    var message = custRemoved ? 'Customer was deleted' : 'Customer not found';
    console.log(message);
}

else{
  console.log('command note recognized'); 
}
