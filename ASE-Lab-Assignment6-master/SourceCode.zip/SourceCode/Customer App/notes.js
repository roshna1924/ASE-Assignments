const fs =  require('fs');


// ------------------Begin of Reusable functions ---------------------

var fetchCustData = () => {
    try {                          //if file won't exist
        var custString = fs.readFileSync('notes-data.json')
        return JSON.parse(custString);
    } catch(e){
        return [];
    }
};

var saveCust = (notes) => {
    fs.writeFileSync('notes-data.json',JSON.stringify(notes));
};


// ------------------End of Reusable functions ---------------------


//  to add a new note

var addCust = (customer_name,customer_id,customer_email,customer_address) => {
    var notes = fetchCustData();
    var note = {customer_name,customer_id,customer_email,customer_address}

    var duplicateNotes =  notes.filter((note) => { // to check if note already exists
        return note.customer_name === customer_name;
    });
    var duplicateNotes1 =  notes.filter((note) => { // to check if note already exists
        return note.customer_id === customer_id;
    });

    if (duplicateNotes.length === 0 && duplicateNotes1.length === 0){
        notes.push(note);
        saveCust(notes);
        return note
    }
};

// to update a customer data
var updateCust = (customer_name,customer_id,customer_email,customer_address) => {
    var notes = fetchCustData();
    var note = {customer_name,customer_id,customer_email,customer_address}

    var duplicateNotes =  notes.filter((note) => { // to check if note already exists
        return note.customer_name === customer_name;
    });

    console.log('duplicates are : '+duplicateNotes.length);

    if (duplicateNotes.length !== 0){
        note.customer_name === customer_name;
        notes.pop(note.customer_name);
        notes.push(note);
        saveCust(notes);
        return note
    }
};

//to list all the notes
var getCustList = () => {
    return fetchCustData();
};


// to read a customer data
var getOneCust = (customer_name) => {

    var notes = fetchCustData();

    var getNotes =  notes.filter((note) => {  // to check if note exists and return note
        return note.customer_name === customer_name;
    });

    return getNotes[0]

};


// to delete a customer
var remove = (customer_name) => {

    var notes = fetchCustData();

    var filteredNotes =  notes.filter((note) => { // will return all other notes other than "note to be removed"
        return note.customer_name !== customer_name;
    });

    saveCust(filteredNotes); //save a new customer array

    return notes.length !== filteredNotes.length

};

// function just to print out customer to screen
var logNote = (note) => {
    console.log('--');
    console.log(`customer_name: ${note.customer_name}`);
    console.log(`customer_id: ${note.customer_id}`);
    console.log(`customer_email : ${note.customer_email}`);
    console.log(`customer_adress : ${note.customer_address}`);
};

// add new function names here to be accessible from other modules

module.exports = {
    addCust, updateCust, getCustList, remove, getOneCust, logNote
};
